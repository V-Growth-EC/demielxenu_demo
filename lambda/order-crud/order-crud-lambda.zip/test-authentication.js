#!/usr/bin/env node

/**
 * Lambda 身份認證測試腳本
 * 測試 API Key 驗證功能
 */

const https = require('https');
const http = require('http');

// 測試配置
const config = {
  // 替換為您的實際 API Gateway URL
  apiUrl: process.env.API_URL || 'https://your-api-gateway-url.amazonaws.com',
  // 替換為您的實際 API Key
  apiKey: process.env.API_KEY || 'your-api-key-here',
  // 測試用的客戶 ID
  testCustomerId: 123
};

/**
 * 發送 HTTP 請求
 * @param {Object} options - 請求選項
 * @param {string} data - 請求數據
 * @returns {Promise} 請求結果
 */
function makeRequest(options, data = null) {
  return new Promise((resolve, reject) => {
    const client = options.protocol === 'https:' ? https : http;
    
    const req = client.request(options, (res) => {
      let body = '';
      res.on('data', (chunk) => body += chunk);
      res.on('end', () => {
        resolve({
          statusCode: res.statusCode,
          headers: res.headers,
          body: body
        });
      });
    });
    
    req.on('error', reject);
    
    if (data) {
      req.write(data);
    }
    
    req.end();
  });
}

/**
 * 測試 API Key 驗證
 */
async function testApiKeyValidation() {
  console.log('🔐 測試 API Key 驗證...\n');
  
  const url = new URL(`${config.apiUrl}/orders`);
  
  // 測試 1: 沒有 API Key
  console.log('測試 1: 沒有 API Key');
  try {
    const response = await makeRequest({
      hostname: url.hostname,
      port: url.port || (url.protocol === 'https:' ? 443 : 80),
      path: url.pathname,
      method: 'GET',
      protocol: url.protocol
    });
    
    console.log(`狀態碼: ${response.statusCode}`);
    console.log(`響應: ${response.body}\n`);
    
    if (response.statusCode === 401) {
      console.log('✅ 測試通過: 正確拒絕沒有 API Key 的請求\n');
    } else {
      console.log('❌ 測試失敗: 應該返回 401 狀態碼\n');
    }
  } catch (error) {
    console.log(`❌ 請求失敗: ${error.message}\n`);
  }
  
  // 測試 2: 無效的 API Key
  console.log('測試 2: 無效的 API Key');
  try {
    const response = await makeRequest({
      hostname: url.hostname,
      port: url.port || (url.protocol === 'https:' ? 443 : 80),
      path: url.pathname,
      method: 'GET',
      protocol: url.protocol,
      headers: {
        'X-Api-Key': 'invalid-api-key',
        'Content-Type': 'application/json'
      }
    });
    
    console.log(`狀態碼: ${response.statusCode}`);
    console.log(`響應: ${response.body}\n`);
    
    if (response.statusCode === 403) {
      console.log('✅ 測試通過: 正確拒絕無效的 API Key\n');
    } else {
      console.log('❌ 測試失敗: 應該返回 403 狀態碼\n');
    }
  } catch (error) {
    console.log(`❌ 請求失敗: ${error.message}\n`);
  }
  
  // 測試 3: 有效的 API Key
  console.log('測試 3: 有效的 API Key');
  try {
    const response = await makeRequest({
      hostname: url.hostname,
      port: url.port || (url.protocol === 'https:' ? 443 : 80),
      path: url.pathname,
      method: 'GET',
      protocol: url.protocol,
      headers: {
        'X-Api-Key': config.apiKey,
        'Content-Type': 'application/json'
      }
    });
    
    console.log(`狀態碼: ${response.statusCode}`);
    console.log(`響應: ${response.body}\n`);
    
    if (response.statusCode === 200) {
      console.log('✅ 測試通過: 有效 API Key 請求成功\n');
    } else {
      console.log(`⚠️  狀態碼: ${response.statusCode} (可能是正常的業務邏輯響應)\n`);
    }
  } catch (error) {
    console.log(`❌ 請求失敗: ${error.message}\n`);
  }
}

/**
 * 測試 CORS 配置
 */
async function testCorsConfiguration() {
  console.log('🌐 測試 CORS 配置...\n');
  
  const url = new URL(`${config.apiUrl}/orders`);
  
  // 測試 OPTIONS 請求
  console.log('測試 OPTIONS 請求 (CORS 預檢)');
  try {
    const response = await makeRequest({
      hostname: url.hostname,
      port: url.port || (url.protocol === 'https:' ? 443 : 80),
      path: url.pathname,
      method: 'OPTIONS',
      protocol: url.protocol,
      headers: {
        'Origin': 'https://test.example.com',
        'Access-Control-Request-Method': 'POST',
        'Access-Control-Request-Headers': 'X-Api-Key,Content-Type'
      }
    });
    
    console.log(`狀態碼: ${response.statusCode}`);
    console.log(`CORS 頭部:`, response.headers);
    
    if (response.statusCode === 200) {
      console.log('✅ CORS 預檢請求成功\n');
    } else {
      console.log('❌ CORS 預檢請求失敗\n');
    }
  } catch (error) {
    console.log(`❌ 請求失敗: ${error.message}\n`);
  }
}

/**
 * 測試訂單操作
 */
async function testOrderOperations() {
  console.log('📦 測試訂單操作...\n');
  
  const url = new URL(`${config.apiUrl}/orders`);
  
  // 測試創建訂單
  console.log('測試創建訂單');
  try {
    const orderData = {
      customer_id: config.testCustomerId,
      order_status: 'pending',
      order_data: {
        items: [
          { id: 1, name: 'Test Item', quantity: 2, price: 50.00 }
        ],
        total: 100.00
      }
    };
    
    const response = await makeRequest({
      hostname: url.hostname,
      port: url.port || (url.protocol === 'https:' ? 443 : 80),
      path: url.pathname,
      method: 'POST',
      protocol: url.protocol,
      headers: {
        'X-Api-Key': config.apiKey,
        'Content-Type': 'application/json'
      }
    }, JSON.stringify(orderData));
    
    console.log(`狀態碼: ${response.statusCode}`);
    console.log(`響應: ${response.body}\n`);
    
    if (response.statusCode === 201) {
      console.log('✅ 訂單創建成功\n');
      
      // 嘗試解析響應以獲取訂單 ID
      try {
        const result = JSON.parse(response.body);
        if (result.order && result.order.order_id) {
          console.log(`📋 創建的訂單 ID: ${result.order.order_id}\n`);
        }
      } catch (parseError) {
        console.log('⚠️  無法解析訂單創建響應\n');
      }
    } else {
      console.log(`⚠️  訂單創建狀態碼: ${response.statusCode}\n`);
    }
  } catch (error) {
    console.log(`❌ 請求失敗: ${error.message}\n`);
  }
}

/**
 * 主測試函數
 */
async function runTests() {
  console.log('🚀 開始 Lambda 身份認證測試\n');
  console.log(`API URL: ${config.apiUrl}`);
  console.log(`API Key: ${config.apiKey.substring(0, 8)}...\n`);
  
  // 檢查配置
  if (config.apiUrl.includes('your-api-gateway-url') || 
      config.apiKey.includes('your-api-key-here')) {
    console.log('⚠️  警告: 請先配置正確的 API_URL 和 API_KEY 環境變數\n');
    console.log('使用方法:');
    console.log('  export API_URL="https://your-actual-api-gateway-url"');
    console.log('  export API_KEY="your-actual-api-key"');
    console.log('  node test-authentication.js\n');
    return;
  }
  
  try {
    await testApiKeyValidation();
    await testCorsConfiguration();
    await testOrderOperations();
    
    console.log('🎉 所有測試完成！');
  } catch (error) {
    console.error('❌ 測試過程中發生錯誤:', error.message);
  }
}

// 如果直接執行此腳本
if (require.main === module) {
  runTests();
}

module.exports = {
  testApiKeyValidation,
  testCorsConfiguration,
  testOrderOperations,
  runTests
};
